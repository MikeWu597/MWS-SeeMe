package com.mws.SeeMe;

import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

public final class SeeMe extends JavaPlugin
{
  String prefix;
  
  
  public void onEnable()
  {
    getLogger().info("§bSeeMe已完成加载！");
    saveDefaultConfig();
    prefix=getConfig().getString("prefix");
    getLogger().info(prefix);
  }
  
  public void onDisable() {}
  
  public String getHelmetItem(Player p)
  {
    String a = "";
    if (p.getInventory().getHelmet().getType() == Material.IRON_HELMET) {
      a = "铁头盔";
    }
    if (p.getInventory().getHelmet().getType() == Material.GOLD_HELMET) {
      a = "金头盔";
    }
    if (p.getInventory().getHelmet().getType() == Material.DIAMOND_HELMET) {
      a = "钻石头盔";
    }
    if (p.getInventory().getHelmet().getType() == Material.LEATHER_HELMET) {
      a = "皮革头盔";
    }
    if (p.getInventory().getHelmet().getType() == Material.CHAINMAIL_HELMET) {
      a = "锁链头盔";
    }
    if (a == "") {
      a = "空气";
    }
    return a;
  }
  
  public String getChestItem(Player p)
  {
    String a = "";
    if (p.getInventory().getChestplate().getType() == Material.IRON_CHESTPLATE) {
      a = "铁胸甲";
    }
    if (p.getInventory().getChestplate().getType() == Material.GOLD_CHESTPLATE) {
      a = "金胸甲";
    }
    if (p.getInventory().getChestplate().getType() == Material.DIAMOND_CHESTPLATE) {
      a = "钻石胸甲";
    }
    if (p.getInventory().getChestplate().getType() == Material.LEATHER_CHESTPLATE) {
      a = "皮革胸甲";
    }
    if (p.getInventory().getChestplate().getType() == Material.CHAINMAIL_CHESTPLATE) {
      a = "锁链胸甲";
    }
    if (a == "") {
      a = "空气";
    }
    return a;
  }
  
  public String getLeggingsItem(Player p)
  {
    String a = "";
    if (p.getInventory().getLeggings().getType() == Material.IRON_LEGGINGS) {
      a = "铁裤子";
    }
    if (p.getInventory().getLeggings().getType() == Material.GOLD_LEGGINGS) {
      a = "金裤子";
    }
    if (p.getInventory().getLeggings().getType() == Material.DIAMOND_LEGGINGS) {
      a = "钻石裤子";
    }
    if (p.getInventory().getLeggings().getType() == Material.LEATHER_LEGGINGS) {
      a = "皮革裤子";
    }
    if (p.getInventory().getLeggings().getType() == Material.CHAINMAIL_LEGGINGS) {
      a = "锁链甲裤子";
    }
    if (a == "") {
      a = "空气";
    }
    return a;
  }
  
  public String getBootItem(Player p)
  {
    String a = "";
    if (p.getInventory().getBoots().getType() == Material.IRON_BOOTS) {
      a = "一双铁靴";
    }
    if (p.getInventory().getBoots().getType() == Material.GOLD_BOOTS) {
      a = "一双金靴";
    }
    if (p.getInventory().getBoots().getType() == Material.DIAMOND_BOOTS) {
      a = "一双钻石靴";
    }
    if (p.getInventory().getBoots().getType() == Material.LEATHER_BOOTS) {
      a = "一双皮革靴";
    }
    if (p.getInventory().getBoots().getType() == Material.CHAINMAIL_BOOTS) {
      a = "一双锁链靴";
    }
    if (a == "") {
      a = "空气";
    }
    return a;
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    if (cmd.getName().equalsIgnoreCase("sm"))
    {
      if (args[0].equalsIgnoreCase("exp"))
      {
        getLogger().info("issued sm");
        Player player = (Player)sender;
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b" + sender.getName() + "§r有§2" + player.getTotalExperience() + "§r经验值!");
        return true;
      }
      if (args[0].equalsIgnoreCase("explv"))
      {
        getLogger().info("issued sm");
        Player player = (Player)sender;
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b" + sender.getName() + "§r有§2" + player.getLevel() + "§r级经验!");
        return true;
      }
      if (args[0].equalsIgnoreCase("expnextlv"))
      {
        getLogger().info("issued sm");
        Player player = (Player)sender;
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b" + sender.getName() + "§r只差§2" + player.getExp() * 200.0F + "%§r就升到下一级了!");
        return true;
      }
      if (args[0].equalsIgnoreCase("lhand"))
      {
        getLogger().info("issued sm");
        Player player = (Player)sender;
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b" + sender.getName() + "§r左手上正拿着§2" + player.getInventory().getItemInOffHand().getType() + "§r向你炫耀!");
        return true;
      }
      if (args[0].equalsIgnoreCase("rhand"))
      {
        getLogger().info("issued sm");
        Player player = (Player)sender;
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b" + sender.getName() + "§r右手上正拿着§2" + player.getInventory().getItemInMainHand().getType() + "§r向你炫耀!");
        return true;
      }
      if (args[0].equalsIgnoreCase("wear"))
      {
        getLogger().info("issued sm");
        Player player = (Player)sender;
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b" + sender.getName() + "§r正穿着§2" + getHelmetItem(player) + "、" + getChestItem(player) + "、" + getLeggingsItem(player) + "以及" + getBootItem(player) + "§r向你炫耀!");
        return true;
      }
      if (args[0].equalsIgnoreCase("help"))
      {
        getLogger().info("issued sm");
        sender.sendMessage("§c§l[§f§lMikeWu's §b§lNetwork§c§l] §2§b\n SeeMe炫耀指令帮助\n\n/sm exp 炫耀经验\n/sm explv 炫耀经验等级\n/sm expnextlv 炫耀离下一级经验的百分比\n/sm lhand 炫耀左手上的物品\n/sm rhand 炫耀右手上的物品\n/sm wear 炫耀防具");
        return true;
      }
    }
    return false;
  }
}
